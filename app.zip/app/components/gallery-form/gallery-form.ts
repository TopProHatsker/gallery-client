import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery-form',
  imports: [],
  templateUrl: './gallery-form.html',
  styleUrl: './gallery-form.scss',
})
export class GalleryForm {}
