import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery-form',
  standalone: true,
  imports: [],
  templateUrl: './gallery-form.component.html',
  styleUrls: ['./gallery-form.component.scss']
})
export class GalleryFormComponent {}