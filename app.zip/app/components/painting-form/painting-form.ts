import { Component } from '@angular/core';

@Component({
  selector: 'app-painting-form',
  imports: [],
  templateUrl: './painting-form.html',
  styleUrl: './painting-form.scss',
})
export class PaintingForm {}
