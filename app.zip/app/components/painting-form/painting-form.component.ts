import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PaintingService } from '../../services/painting.service';
import { GalleryService } from '../../services/gallery.service';

@Component({
  selector: 'app-painting-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="container mt-4">
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card shadow">
            <div class="card-header bg-primary text-white">
              <h4 class="mb-0">{{ isEditMode ? 'Редактировать' : 'Добавить' }} картину</h4>
            </div>
            <div class="card-body">
              <form #paintingForm="ngForm" (ngSubmit)="onSubmit()">
                <!-- Инвентарный номер -->
                <div class="mb-3">
                  <label class="form-label">Инвентарный номер *</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.inventoryNumber" 
                    name="inventoryNumber"
                    required
                    #inventoryNumberInput="ngModel"
                  >
                  <div *ngIf="inventoryNumberInput.invalid && inventoryNumberInput.touched" class="text-danger small">
                    Обязательное поле
                  </div>
                </div>

                <!-- Название -->
                <div class="mb-3">
                  <label class="form-label">Название *</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.title" 
                    name="title"
                    required
                    #titleInput="ngModel"
                  >
                  <div *ngIf="titleInput.invalid && titleInput.touched" class="text-danger small">
                    Обязательное поле
                  </div>
                </div>

                <!-- Художник -->
                <div class="mb-3">
                  <label class="form-label">Художник *</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.artist" 
                    name="artist"
                    required
                    #artistInput="ngModel"
                  >
                  <div *ngIf="artistInput.invalid && artistInput.touched" class="text-danger small">
                    Обязательное поле
                  </div>
                </div>

                <!-- Год создания -->
                <div class="mb-3">
                  <label class="form-label">Год создания</label>
                  <input 
                    type="number" 
                    class="form-control" 
                    [(ngModel)]="formData.yearCreated" 
                    name="yearCreated"
                  >
                </div>

                <!-- Техника -->
                <div class="mb-3">
                  <label class="form-label">Техника</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.technique" 
                    name="technique"
                    placeholder="например: холст, масло"
                  >
                </div>

                <!-- Размеры -->
                <div class="mb-3">
                  <label class="form-label">Размеры</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.dimensions" 
                    name="dimensions"
                    placeholder="например: 100x150 см"
                  >
                </div>

                <!-- Жанр -->
                <div class="mb-3">
                  <label class="form-label">Жанр</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    [(ngModel)]="formData.genre" 
                    name="genre"
                  >
                </div>

                <!-- Дата поступления -->
                <div class="mb-3">
                  <label class="form-label">Дата поступления</label>
                  <input 
                    type="datetime-local" 
                    class="form-control" 
                    [(ngModel)]="formData.acquisitionDate" 
                    name="acquisitionDate"
                  >
                </div>

                <!-- Галерея -->
                <div class="mb-3">
                  <label class="form-label">Галерея *</label>
                  <select 
                    class="form-control" 
                    [(ngModel)]="formData.galleryId" 
                    name="galleryId"
                    required
                    #galleryIdInput="ngModel"
                  >
                    <option value="">Выберите галерею</option>
                    <option *ngFor="let gallery of galleries" [value]="gallery.id">
                      {{ gallery.name }}
                    </option>
                  </select>
                  <div *ngIf="galleryIdInput.invalid && galleryIdInput.touched" class="text-danger small">
                    Выберите галерею
                  </div>
                </div>

                <div *ngIf="errorMessage" class="alert alert-danger">
                  {{ errorMessage }}
                </div>

                <div class="d-flex justify-content-between">
                  <a routerLink="/paintings" class="btn btn-secondary">
                    <i class="fas fa-times me-2"></i>Отмена
                  </a>
                  <button 
                    type="submit" 
                    class="btn btn-primary"
                    [disabled]="paintingForm.invalid || loading"
                  >
                    <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
                    <i class="fas fa-save me-2"></i>{{ isEditMode ? 'Сохранить' : 'Создать' }}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      border-radius: 10px;
    }
    .card-header {
      border-radius: 10px 10px 0 0;
    }
  `]
})
export class PaintingFormComponent implements OnInit {
  formData: any = {
    inventoryNumber: '',
    title: '',
    artist: '',
    yearCreated: null,
    technique: '',
    dimensions: '',
    genre: '',
    acquisitionDate: '',
    galleryId: ''
  };
  galleries: any[] = [];
  isEditMode = false;
  paintingId: number | null = null;
  loading = false;
  errorMessage = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private paintingService: PaintingService,
    private galleryService: GalleryService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadGalleries();
    
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.paintingId = +params['id'];
        this.loadPainting(this.paintingId);
      }
    });
  }

  loadGalleries() {
    this.galleryService.getAll().subscribe({
      next: (data) => {
        this.galleries = data;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Ошибка загрузки галерей:', err);
        this.errorMessage = 'Не удалось загрузить список галерей';
        this.cdr.detectChanges();
      }
    });
  }

  loadPainting(id: number) {
    this.loading = true;
    this.paintingService.getById(id).subscribe({
      next: (data) => {
        // Форматируем дату для input type="datetime-local"
        if (data.acquisitionDate) {
          const date = new Date(data.acquisitionDate);
          data.acquisitionDate = date.toISOString().slice(0, 16);
        }
        this.formData = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Ошибка загрузки картины:', err);
        this.errorMessage = 'Не удалось загрузить данные картины';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

onSubmit() {
  if (!this.formData.inventoryNumber || !this.formData.title || !this.formData.artist || !this.formData.galleryId) {
    this.errorMessage = 'Заполните все обязательные поля';
    return;
  }

  // Подготовим данные для отправки
  const paintingData = {
    inventoryNumber: this.formData.inventoryNumber,
    title: this.formData.title,
    artist: this.formData.artist,
    yearCreated: this.formData.yearCreated ? Number(this.formData.yearCreated) : null,
    technique: this.formData.technique || '',
    dimensions: this.formData.dimensions || '',
    genre: this.formData.genre || '',
    acquisitionDate: this.formData.acquisitionDate || new Date().toISOString().slice(0, 16), // ← текущая дата, если не указана
    galleryId: Number(this.formData.galleryId)
  };

  console.log('Отправляемые данные:', paintingData);

  this.loading = true;
  this.errorMessage = '';

  const request = this.isEditMode && this.paintingId
    ? this.paintingService.update(this.paintingId, paintingData)
    : this.paintingService.create(paintingData);

  request.subscribe({
    next: () => {
      this.router.navigate(['/paintings']);
    },
    error: (err) => {
      console.error('Ошибка сохранения:', err);
      this.errorMessage = 'Ошибка при сохранении картины';
      this.loading = false;
      this.cdr.detectChanges();
    }
  });
}
}