import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaintingForm } from './painting-form';

describe('PaintingForm', () => {
  let component: PaintingForm;
  let fixture: ComponentFixture<PaintingForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaintingForm],
    }).compileComponents();

    fixture = TestBed.createComponent(PaintingForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
