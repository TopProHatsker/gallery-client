import { Component } from '@angular/core';

@Component({
  selector: 'app-painting-card',
  standalone: true,
  imports: [],
  templateUrl: './painting-card.component.html',
  styleUrls: ['./painting-card.component.scss']
})
export class PaintingCardComponent {}