import { Component } from '@angular/core';

@Component({
  selector: 'app-painting-card',
  imports: [],
  templateUrl: './painting-card.html',
  styleUrl: './painting-card.scss',
})
export class PaintingCard {}
