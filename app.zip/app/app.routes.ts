import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { GalleriesComponent } from './pages/galleries/galleries.component';
import { GalleryDetailComponent } from './pages/gallery-detail/gallery-detail.component';
import { PaintingsComponent } from './pages/paintings/paintings.component';
import { PaintingDetailComponent } from './pages/painting-detail/painting-detail.component';
import { HomeComponent } from './pages/home/home.component';
import { PaintingFormComponent } from './components/painting-form/painting-form.component';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'galleries', component: GalleriesComponent },
  { path: 'galleries/:id', component: GalleryDetailComponent },
  { path: 'paintings', component: PaintingsComponent },
  { path: 'paintings/new', component: PaintingFormComponent, canActivate: [authGuard] },
  { path: 'paintings/edit/:id', component: PaintingFormComponent, canActivate: [authGuard] },
  { path: 'paintings/:id', component: PaintingDetailComponent },
  { path: '**', redirectTo: '' }
];