import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class PaintingService {
  private apiUrl = 'https://localhost:7192/api/paintings';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getAll(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  getById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  getByGallery(galleryId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/gallery/${galleryId}`);
  }

  create(data: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, data, { headers: this.getHeaders() });
  }

  update(id: number, data: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, data, { headers: this.getHeaders() });
  }

  delete(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }

  searchByTitle(title: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/search?title=${title}`);
  }

  getByArtist(artist: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/artist/${artist}`);
  }

  getTopArtists(count: number = 10): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/top-artists?count=${count}`);
  }
}