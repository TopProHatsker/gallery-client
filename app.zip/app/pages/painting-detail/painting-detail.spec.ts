import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaintingDetail } from './painting-detail';

describe('PaintingDetail', () => {
  let component: PaintingDetail;
  let fixture: ComponentFixture<PaintingDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaintingDetail],
    }).compileComponents();

    fixture = TestBed.createComponent(PaintingDetail);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
