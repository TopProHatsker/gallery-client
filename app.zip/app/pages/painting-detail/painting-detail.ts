import { Component } from '@angular/core';

@Component({
  selector: 'app-painting-detail',
  imports: [],
  templateUrl: './painting-detail.html',
  styleUrl: './painting-detail.scss',
})
export class PaintingDetail {}
