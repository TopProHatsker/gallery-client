import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-painting-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-4">
      <h2>Детали картины</h2>
      <p>Страница в разработке</p>
    </div>
  `
})
export class PaintingDetailComponent {}