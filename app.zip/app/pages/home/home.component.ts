import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PaintingService } from '../../services/painting.service';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  searchQuery: string = '';
  searchResults: any[] = [];
  loading = false;
  searchPerformed = false;

  constructor(
    private paintingService: PaintingService,
    private cdr: ChangeDetectorRef
  ) {}

  async onSearch() {
    if (this.searchQuery.length < 2) {
      this.searchResults = [];
      this.searchPerformed = false;
      this.cdr.detectChanges();
      return;
    }

    this.loading = true;
    this.searchPerformed = true;
    this.cdr.detectChanges();

    try {
      // Выполняем оба запроса параллельно
      const [titleResults, artistResults] = await Promise.all([
        lastValueFrom(this.paintingService.searchByTitle(this.searchQuery)),
        lastValueFrom(this.paintingService.getByArtist(this.searchQuery))
      ]);

      // Объединяем результаты
      const allResults = [...(titleResults || []), ...(artistResults || [])];
      
      // Убираем дубликаты по id
      const uniqueResults = Array.from(
        new Map(allResults.map(item => [item.id, item])).values()
      );

      console.log('Результаты поиска:', uniqueResults);
      this.searchResults = uniqueResults;
    } catch (err) {
      console.error('Ошибка поиска:', err);
      this.searchResults = [];
    } finally {
      this.loading = false;
      this.cdr.detectChanges();
    }
  }

  clearSearch() {
    this.searchQuery = '';
    this.searchResults = [];
    this.searchPerformed = false;
    this.cdr.detectChanges();
  }
}