import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { PaintingService } from '../../services/painting.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-paintings',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container mt-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Картины</h2>
        <button 
          *ngIf="isLoggedIn$ | async" 
          class="btn btn-primary" 
          routerLink="/paintings/new"
        >
          <i class="fas fa-plus me-2"></i>Добавить картину
        </button>
      </div>

      <!-- Сообщение для неавторизованных -->
      <div *ngIf="!(isLoggedIn$ | async)" class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>
        Для добавления, редактирования и удаления картин необходимо 
        <a routerLink="/login" class="alert-link">войти</a>.
      </div>

      <div *ngIf="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Загрузка...</span>
        </div>
      </div>

      <div *ngIf="!loading && paintings.length === 0" class="text-center text-muted py-5">
        <i class="fas fa-image fa-4x mb-3"></i>
        <p class="lead">Нет картин в базе данных</p>
      </div>

      <div *ngIf="!loading && paintings.length > 0" class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <div *ngFor="let painting of paintings" class="col">
          <div class="card h-100 shadow-sm">
            <div class="card-body">
              <h5 class="card-title">{{ painting.title }}</h5>
              <h6 class="card-subtitle mb-2 text-muted">{{ painting.artist }}</h6>
              <p class="card-text small">
                <span class="badge bg-secondary me-1">{{ painting.yearCreated || '?' }}</span>
                <span class="badge bg-info">{{ painting.genre || '?' }}</span>
              </p>
              <p class="card-text small">
                <i class="fas fa-building me-1"></i>{{ painting.galleryName }}
              </p>
            </div>
            <div class="card-footer bg-transparent">
              <div class="d-flex justify-content-end">
                <div *ngIf="isLoggedIn$ | async">
                  <a [routerLink]="['/paintings/edit', painting.id]" class="btn btn-sm btn-outline-secondary me-1">
                    <i class="fas fa-edit"></i>
                  </a>
                  <button class="btn btn-sm btn-outline-danger" (click)="deletePainting(painting.id)">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card-footer .btn-sm {
      padding: 0.25rem 0.5rem;
    }
  `]
})
export class PaintingsComponent implements OnInit {
  paintings: any[] = [];
  loading = false;
  isLoggedIn$: any;

  constructor(
    private paintingService: PaintingService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {
    this.isLoggedIn$ = this.authService.isLoggedIn();
  }

  ngOnInit() {
    this.loadPaintings();
  }

  loadPaintings() {
    this.loading = true;
    this.paintingService.getAll().subscribe({
      next: (data) => {
        this.paintings = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Ошибка загрузки:', err);
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  deletePainting(id: number) {
    if (confirm('Вы уверены, что хотите удалить эту картину?')) {
      this.paintingService.delete(id).subscribe({
        next: () => {
          this.loadPaintings();
        },
        error: (err) => {
          console.error('Ошибка удаления:', err);
          alert('Ошибка при удалении картины');
        }
      });
    }
  }
}