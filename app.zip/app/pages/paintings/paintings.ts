import { Component } from '@angular/core';

@Component({
  selector: 'app-paintings',
  imports: [],
  templateUrl: './paintings.html',
  styleUrl: './paintings.scss',
})
export class Paintings {}
