import { Component, OnInit, ChangeDetectorRef } from '@angular/core'; // ← добавить ChangeDetectorRef
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { GalleryService } from '../../services/gallery.service';
import { PaintingService } from '../../services/painting.service';

@Component({
  selector: 'app-gallery-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container mt-4">
      <div class="mb-3">
        <a routerLink="/galleries" class="btn btn-outline-secondary">
          <i class="fas fa-arrow-left me-2"></i>Назад к галереям
        </a>
      </div>

      <div *ngIf="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Загрузка...</span>
        </div>
      </div>

      <div *ngIf="error" class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        Ошибка загрузки данных
      </div>

      <div *ngIf="!loading && !error && gallery">
        <div class="card shadow-sm mb-4">
          <div class="card-header bg-primary text-white">
            <h4 class="mb-0">{{ gallery.name }}</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <p><strong>Город:</strong> {{ gallery.city || 'Не указан' }}</p>
                <p><strong>Адрес:</strong> {{ gallery.address || 'Не указан' }}</p>
              </div>
              <div class="col-md-6">
                <p><strong>Год основания:</strong> {{ gallery.foundedYear || 'Не указан' }}</p>
                <p><strong>Сайт:</strong> 
                  <a *ngIf="gallery.websiteUrl" [href]="gallery.websiteUrl" target="_blank">{{ gallery.websiteUrl }}</a>
                  <span *ngIf="!gallery.websiteUrl">Не указан</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        <h3 class="mb-3">Картины в этой галерее</h3>

        <div *ngIf="paintingsLoading" class="text-center py-4">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Загрузка...</span>
          </div>
        </div>

        <div *ngIf="!paintingsLoading && paintings.length === 0" class="text-center text-muted py-5">
          <i class="fas fa-image fa-4x mb-3"></i>
          <p>В этой галерее пока нет картин</p>
        </div>

        <div *ngIf="!paintingsLoading && paintings.length > 0" class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          <div *ngFor="let painting of paintings" class="col">
            <div class="card h-100 shadow-sm">
              <div class="card-body">
                <h5 class="card-title">{{ painting.title }}</h5>
                <h6 class="card-subtitle mb-2 text-muted">{{ painting.artist }}</h6>
                <p class="card-text small">
                  <span class="badge bg-secondary">{{ painting.yearCreated || '?' }}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class GalleryDetailComponent implements OnInit {
  gallery: any = null;
  paintings: any[] = [];
  loading = false;
  paintingsLoading = false;
  error = false;
  galleryId: number = 0;

  constructor(
    private route: ActivatedRoute,
    private galleryService: GalleryService,
    private paintingService: PaintingService,
    private cdr: ChangeDetectorRef // ← добавить
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.galleryId = +params['id'];
      this.loadGallery();
      this.loadPaintings();
    });
  }

  loadGallery() {
    this.loading = true;
    this.galleryService.getById(this.galleryId).subscribe({
      next: (data) => {
        console.log('Галерея загружена:', data);
        this.gallery = data;
        this.loading = false;
        this.cdr.detectChanges(); // ← добавить
      },
      error: (err) => {
        console.error('Ошибка загрузки галереи:', err);
        this.error = true;
        this.loading = false;
        this.cdr.detectChanges(); // ← добавить
      }
    });
  }

  loadPaintings() {
    this.paintingsLoading = true;
    console.log('Загружаем картинки для галереи ID:', this.galleryId);
    
    this.paintingService.getByGallery(this.galleryId).subscribe({
      next: (data) => {
        console.log('Картинки получены:', data);
        this.paintings = data;
        this.paintingsLoading = false;
        this.cdr.detectChanges(); // ← добавить
      },
      error: (err) => {
        console.error('Ошибка загрузки картин:', err);
        this.paintingsLoading = false;
        this.cdr.detectChanges(); // ← добавить
      }
    });
  }
}