import { Component } from '@angular/core';

@Component({
  selector: 'app-galleries',
  imports: [],
  templateUrl: './galleries.html',
  styleUrl: './galleries.scss',
})
export class Galleries {}
