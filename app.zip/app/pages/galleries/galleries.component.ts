import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GalleryService } from '../../services/gallery.service';
import { AuthService } from '../../services/auth.service';
import { RouterLink, Router } from '@angular/router';

@Component({
  selector: 'app-galleries',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './galleries.component.html',
  styleUrls: ['./galleries.component.scss']
})
export class GalleriesComponent implements OnInit {
  galleries: any[] = [];
  loading = false;
  isLoggedIn$: any;
  showModal = false;
  modalTitle = '';
  formData: any = {};
  editId: number | null = null;

  constructor(
    private galleryService: GalleryService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {
    this.isLoggedIn$ = this.authService.isLoggedIn();
  }

  ngOnInit() {
    this.loadGalleries();
  }

  loadGalleries() {
    this.loading = true;
    this.galleryService.getAll().subscribe({
      next: (data) => {
        console.log('Галереи загружены:', data);
        this.galleries = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Ошибка загрузки галерей:', err);
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  viewGallery(id: number) {
    this.router.navigate(['/galleries', id]);
  }

  openCreateModal() {
    this.modalTitle = 'Добавить галерею';
    this.formData = {};
    this.editId = null;
    this.showModal = true;
  }

  editGallery(id: number) {
    this.modalTitle = 'Редактировать галерею';
    this.editId = id;
    const gallery = this.galleries.find(g => g.id === id);
    this.formData = { ...gallery };
    this.showModal = true;
  }

  deleteGallery(id: number) {
    if (confirm('Вы уверены, что хотите удалить галерею?')) {
      this.galleryService.delete(id).subscribe({
        next: () => {
          this.loadGalleries();
        },
        error: (err) => {
          console.error('Ошибка при удалении:', err);
          alert('Ошибка при удалении галереи');
        }
      });
    }
  }

  saveGallery() {
    if (!this.formData.name) {
      alert('Название обязательно');
      return;
    }

    console.log('Сохраняем галерею:', this.formData);

    const request = this.editId 
      ? this.galleryService.update(this.editId, this.formData)
      : this.galleryService.create(this.formData);

    request.subscribe({
      next: (response) => {
        console.log('Сохранение успешно:', response);
        this.showModal = false;
        this.loadGalleries();
      },
      error: (err) => {
        console.error('Ошибка при сохранении:', err);
        alert('Ошибка при сохранении галереи. Проверь консоль для деталей.');
      }
    });
  }

  closeModal() {
    this.showModal = false;
  }
}