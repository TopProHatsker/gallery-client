import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-4">
        <div class="card shadow mt-5">
          <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Вход в систему</h4>
          </div>
          <div class="card-body">
            <form #loginForm="ngForm" (ngSubmit)="onSubmit()">
              <div class="mb-3">
                <label class="form-label">Имя пользователя</label>
                <input
                  type="text"
                  class="form-control"
                  name="username"
                  [(ngModel)]="username"
                  required
                  minlength="3"
                  #usernameInput="ngModel"
                >
                <div *ngIf="usernameInput.invalid && usernameInput.touched" class="text-danger small">
                  <div *ngIf="usernameInput.errors?.['required']">Обязательное поле</div>
                  <div *ngIf="usernameInput.errors?.['minlength']">Минимум 3 символа</div>
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label">Пароль</label>
                <input
                  type="password"
                  class="form-control"
                  name="password"
                  [(ngModel)]="password"
                  required
                  minlength="3"
                  #passwordInput="ngModel"
                >
                <div *ngIf="passwordInput.invalid && passwordInput.touched" class="text-danger small">
                  <div *ngIf="passwordInput.errors?.['required']">Обязательное поле</div>
                  <div *ngIf="passwordInput.errors?.['minlength']">Минимум 3 символа</div>
                </div>
              </div>

              <div *ngIf="errorMessage" class="alert alert-danger">
                {{ errorMessage }}
              </div>

              <button
                type="submit"
                class="btn btn-primary w-100"
                [disabled]="loginForm.invalid"
              >
                Войти
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card { border-radius: 10px; }
    .card-header { border-radius: 10px 10px 0 0; }
  `]
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    this.authService.login(this.username, this.password).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (err) => {
        this.errorMessage = 'Неверное имя пользователя или пароль';
        console.error(err);
      }
    });
  }
}